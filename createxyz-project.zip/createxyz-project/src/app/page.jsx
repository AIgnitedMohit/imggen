"use client";
import React from "react";
import Component3DButtonDesign from "../components/component-3-d-button-design";
import NewComponent from "../components/new-component";

function MainComponent() {
  const [prompt, setPrompt] = React.useState("");
  const [imageUrls, setImageUrls] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [imageSize, setImageSize] = React.useState("256x256");
  const [numImages, setNumImages] = React.useState(1);
  const [history, setHistory] = React.useState([]);
  const [cancelToken, setCancelToken] = React.useState(null);
  const [joke, setJoke] = React.useState("");
  const [quote, setQuote] = React.useState("");
  const randomImages = [
    "/images/random1.jpg",
    "/images/random2.jpg",
    "/images/random3.jpg",
    "/images/random4.jpg",
    "/images/random5.jpg",
    "/images/random6.jpg",
  ];

  const jokes = [
    "Why did the AI refuse to generate an image? It was feeling a bit pixelated!",
    "I tried to generate a picture of procrastination, but the AI said it'll do it later.",
    "The AI asked me for a prompt, so I said 'please'. It replied, 'That's polite, not a prompt!'",
    "I asked the AI to draw a blank, and it gave me a masterpiece of nothingness!",
    "Why did the image generator go to therapy? It had too many unresolved issues!",
  ];

  const quotes = [
    "Patience is the key to magic.",
    "Good things come to those who wait.",
    "Magic happens when you believe.",
    "Art is magic revealed.",
    "Your vision will come to life soon!",
  ];

  const generateImage = async () => {
    if (!prompt.trim()) {
      setJoke(jokes[Math.floor(Math.random() * jokes.length)]);
      return;
    }

    setJoke("");
    setQuote(quotes[Math.floor(Math.random() * quotes.length)]);
    setLoading(true);
    const fetchedImages = [];
    const token = {};
    setCancelToken(token);

    for (let i = 0; i < numImages; i++) {
      if (token.cancelled) break;
      try {
        const response = await fetch(
          `/integrations/dall-e-3/?prompt=${encodeURIComponent(
            prompt
          )}&size=${imageSize}`,
          {
            method: "GET",
          }
        );
        const result = await response.json();
        fetchedImages.push(result.data[0]);
      } catch (error) {
        console.error("Error generating image:", error);
      }
    }

    if (!token.cancelled) {
      setImageUrls(fetchedImages);
      setHistory([...history, ...fetchedImages]);
    }
    setLoading(false);
    setPrompt("");
    setCancelToken(null);
  };

  const cancelGeneration = () => {
    if (cancelToken) {
      cancelToken.cancelled = true;
      setLoading(false);
      setCancelToken(null);
    }
  };

  return (
    <div className="relative min-h-screen flex flex-col">
      <nav className="w-full flex justify-between items-center bg-white shadow-md p-4">
        <div className="text-black text-2xl font-bold">IMGEN</div>
        <div className="text-black">
          <i className="fas fa-user-circle text-3xl"></i>
        </div>
      </nav>

      <div className="flex-grow relative flex flex-col items-center justify-center text-white">
        <div className="absolute inset-0 grid grid-cols-2 md:grid-cols-3 gap-2 opacity-50 filter blur-sm">
          {randomImages.map((src, index) => (
            <img
              key={index}
              src={src}
              alt={`Random AI Generated ${index + 1}`}
              className="w-full h-full object-cover"
            />
          ))}
        </div>

        <div
          className={`relative z-10 text-center mb-2 ${
            history.length > 0 ? "mt-10 p-4" : ""
          }`}
        >
          <NewComponent text="Keep the Magic Flowing" />
          <p className="text-xl mb-10 text-black">
            Image Generator by <span className="italic text-2xl">Mohit</span>
          </p>
        </div>

        <div className="relative z-10 flex flex-col items-center bg-gradient-to-r from-orange-500 to-white p-8 rounded-md shadow-lg">
          <input
            className="mb-4 p-3 w-full md:w-[300px] bg-white text-black border border-gray-300 focus:outline-none focus:ring focus:ring-gray-400"
            type="text"
            name="prompt"
            placeholder="Create magic"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <select
            className="mb-4 p-2 text-black bg-white border border-gray-300 focus:outline-none"
            value={imageSize}
            onChange={(e) => setImageSize(e.target.value)}
          >
            <option value="256x256">256x256</option>
            <option value="512x512">512x512</option>
            <option value="1024x1024">1024x1024</option>
          </select>
          <select
            className="mb-4 p-2 text-black bg-white border border-gray-300 focus:outline-none"
            value={numImages}
            onChange={(e) => setNumImages(e.target.value)}
          >
            <option value="1">1 Image</option>
            <option value="2">2 Images</option>
            <option value="3">3 Images</option>
            <option value="4">4 Images</option>
          </select>
          {!loading ? (
            <Component3DButtonDesign onClick={generateImage}>
              Generate Image
            </Component3DButtonDesign>
          ) : (
            <button
              className="w-full md:w-auto bg-red-600 hover:bg-red-700 text-white py-2 px-6 rounded-full transition duration-300 ease-in-out transform hover:scale-105"
              onClick={cancelGeneration}
            >
              Cancel Generation
            </button>
          )}
          {loading && (
            <div className="text-black mt-4 flex flex-col items-center space-y-2">
              <i className="fas fa-spinner fa-spin"></i>
              <span>{quote}</span>
            </div>
          )}
          {joke && (
            <div className="text-black mt-4 text-center">
              <p className="font-bold">Oops! Don't forget the magic words:</p>
              <p className="italic">{joke}</p>
            </div>
          )}
        </div>

        {history.length > 0 && (
          <div className="relative z-10 mt-10 bg-gray-100 p-4 rounded-md shadow-md">
            <h2 className="text-2xl mb-4">Previous Generations</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {history.map((image, index) => (
                <div
                  key={index}
                  className="p-2 border border-gray-300 rounded-md"
                >
                  <a href={image} target="_blank" rel="noopener noreferrer">
                    <img
                      src={image}
                      alt={`Generated visual #${index + 1}`}
                      className={`max-w-full h-auto object-cover ${
                        imageSize === "256x256"
                          ? "w-[256px] h-[256px]"
                          : imageSize === "512x512"
                          ? "w-[512px] h-[512px]"
                          : "w-[1024px] h-[1024px]"
                      }`}
                    />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <style jsx global>{`
        @keyframes typing {
          from { width: 0; }
          to { width: 100%; }
        }
        .animation-typing {
          border-right: 2px solid white;
          white-space: nowrap;
          overflow: hidden;
          animation: typing 3.5s steps(35, end), blink-caret 0.75s step-end infinite;
        }
        @keyframes blink-caret {
          from, to { border-color: transparent; }
          50% { border-color: white; }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;