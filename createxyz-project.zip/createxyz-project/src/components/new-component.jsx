"use client";
import React from "react";

function NewComponent({ text }) {
  return (
    <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-white font-atkinson-hyperlegible">
      {text} ✨
    </h1>
  );
}

function NewComponentStory() {
  return (
    <div>
      <NewComponent text="Keep the Magic Flowing" />
    </div>
  );
}

export default NewComponent;